package com.gb.rating.ui.cafeInfo

import androidx.lifecycle.ViewModel

class CafeInfoViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
