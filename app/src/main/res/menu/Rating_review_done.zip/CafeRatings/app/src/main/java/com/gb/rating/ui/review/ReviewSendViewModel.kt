package com.gb.rating.ui.review

import androidx.lifecycle.ViewModel
import com.gb.rating.models.usercase.UnverifiedRatingInteractor

class ReviewSendViewModel(unverifiedRatingInteractor : UnverifiedRatingInteractor) : ViewModel() {
}